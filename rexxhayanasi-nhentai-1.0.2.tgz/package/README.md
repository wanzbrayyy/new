
<div align="center">
  <h1>📘 Nhentai API</h1>

  
  <p><em>API that allows you to download Nhentai via bot or other methods using my api</em></p>

  <img src="https://files.catbox.moe/q4zj9m.png" width="300" height="300" alt="Nhentai Banner" />
 
---


[![NPM](https://img.shields.io/badge/Available%20On-NPM-lightgrey.svg?logo=npm&logoColor=339933&labelColor=white&style=flat-square)](https://www.npmjs.com/package/@rexxhayanasi/nhentai)

> TypeScript wrapper to scrape doujins and generate PDFs from NHentai and its mirror sites.

📖 **Documentation:** [coming soon] 

🌐 **Supported Sites:** [https://nhentai.net|https://nhentai.to] 

*will be updated if there is a change in the domain from nhentai official*


---

## ⚙️ Installation

```bash
yarn add @rexxhayanasi/nhentai
# or
npm install @rexxhayanasi/nhentai
```

---

⚠️ Note for nhentai.net Users

Due to Cloudflare protection on nhentai.net, follow these steps:

1. Open nhentai.net in your browser.

2. Open Developer Tools (DevTools).

3. Set a custom User-Agent (you'll use this later).

4. Wait for Cloudflare clearance (do not close DevTools).

5. Copy the cf_clearance cookie value from the Network tab.

> ⏳ The cookie expires after 30 minutes of inactivity, so you may need to repeat this process if needed.




---

### 🚀 Usage Examples

<details>
<summary>🏠 <strong>Explore Doujins</strong></summary>
  
  ```js
  import { NHentai } from '@rexxhayanasi/nhentai'

const nhentai = new NHentai()

;(async () => {
  const { data } = await nhentai.explore()
  console.log(data)
})()
```
</details>
---

<details>
<summary>🔍 <strong>Search & Generate PDF</strong></summary>
  
  ```js
  import { NHentai } from '@rexxhayanasi/nhentai'

const nhentai = new NHentai()

;(async () => {
  const { data } = await nhentai.search('loli', { page: 1 })
  const doujin = data[0]

  const { images } = await doujin.getContents()
  console.log(images.pages)

  await images.PDF('loli.pdf') // Returns Buffer if no filename
})()
```
</details>
---

<details>
<summary>🛡️ <strong>Use with Cloudflare Bypass</strong></summary>

  ```js
  import { NHentai } from '@rexxhayanasi/nhentai'

const nhentai = new NHentai({
  site: 'nhentai.net',
  user_agent: 'Your Custom User-Agent',
  cookie_value: 'cf_clearance=your_cookie_here'
})

;(async () => {
  const { data } = await nhentai.explore()
  console.log(data)
})()
```
or using default Cookies Npm @rexxhayanasi/nhentai (MAY NOT WORK)
```js
import { NHentai } from '@rexxhayanasi/nhentai'

const nhentai = new NHentai({
  site: 'nhentai.net',
  user_agent: 'Your Custom User-Agent'
})
//no cookie_content if this Npm has prepared manual cookies

;(async () => {
  const { data } = await nhentai.explore()
  console.log(data)
})()
```
</details>
---

<details>
<summary>🔢 <strong>Validate Doujin ID</strong></summary>
  
  ```js
import { NHentai } from '@rexxhayanasi/nhentai'

const nhentai = new NHentai({ site: 'nhentai.to' })
nhentai.validate('172').then(console.log)
```
</details>
---

<details>
<summary>📖 <strong>Get Doujin by ID</strong></summary>
  
  ```js
import { NHentai } from '@rexxhayanasi/nhentai'

const nhentai = new NHentai()
nhentai.getDoujin(172).then(console.log)
```
</details>
---

<details>
<summary>🎲 <strong>Get Random Doujin</strong></summary>
  
  ```js
  import { NHentai } from '@rexxhayanasi/nhentai'

const nhentai = new NHentai()
nhentai.getRandom().then(console.log)
```
</details>
---

<details>
<summary>📥 <strong>Download Doujin Images</strong></summary>
  
  ```js
  import { NHentai } from '@rexxhayanasi/nhentai'

const nhentai = new NHentai()

nhentai.getDoujin('2456').then(async (res) => {
  await res.images.download('nhentai') // Save to folder
})
```
</details>
---

<details>
<summary>🗜️ <strong>Export as Zip</strong></summary>
  
  ```js
  import { NHentai } from '@rexxhayanasi/nhentai'

const nhentai = new NHentai()

nhentai.getRandom().then(async (res) => {
  await res.images.zip('nhentai.zip') // Returns Buffer if no filename
})
```
</details>
---

📬 License & Contributions

Licensed under MIT.
Feel free to open issues or contribute via pull requests!


---

> ⚠️ This is not an official NHentai API. Use responsibly.
